<?php
    $mydb = new mysqli("localhost", "root", "", "user_info");

    if ($mydb->connect_errno) {
        echo "Failed to connect to the database: " . $mydb->connect_error;
        exit();
    }

    if (isset($_POST['add'])) {
        $name = mysqli_real_escape_string($mydb, $_POST['name']);

        // Validate the 'price' field as a numeric value
        $price = is_numeric($_POST['price']) ? $_POST['price'] : 0;

        $description = mysqli_real_escape_string($mydb, $_POST['description']);

        // Validate the 'quantity' field as a numeric value
        $quantity = is_numeric($_POST['quantity']) ? $_POST['quantity'] : 0;

        $insert_query = "INSERT INTO product_table (product_name, price, description, quantity) VALUES ('$name', $price, '$description', $quantity)";

        $insert_result = mysqli_query($mydb, $insert_query);

        if($insert_result)
    {   echo "<div class='message'>";
        echo "<p id='success-message'>Record inserted successfully</p>";
        echo "</div>";
    }else
    {
        echo "<p id='failure-message'>Something went wrong"  . mysqli_error($mydb) ." </p>";
    }
        
    }
?>


<html>
    <head>
        <title>Dashboard</title>
        <link href="admin.css" rel="stylesheet">
        
    </head>
    <body>
        <header>
            <ul id="menu">
                <li><a href="inventory.php">Inventory</a></li>
                <li><a href="admin.php">Dashboard</a></li>
            </ul>
        </header>


        <h1 id="msg">Dashboard</h1>

        <form action="admin.php" method="post" enctype="multipart/form-data">
            <div>
                <label class="label" for="product_name">Product Name</label>
                <input class="information" type="text" name="name" required>
            </div>

            <div>
                <label class="label" for="price">Price</label>
                <input class="information" type="text" name="price"required>
            </div>

            <div>
                <label class="label" for="description">Description</label>
                <textarea class="information" name="description" required></textarea>
            </div>

            <div>
                <label class="label" for="quantity">Quantity</label>
                <input class="information" type="number" name="quantity" required>
            </div>


            <div>
                <Input type="submit" id="submit" name="add" value="Add Product">
            </div>
        </form>
        <script src="code.jquery.com_jquery-3.7.1.js"></script>
        <script src="admin.js"></script>
    </body>
</html>