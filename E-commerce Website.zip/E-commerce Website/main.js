"use strict"

$(document).ready(() =>{
   //Declares variables//
    const width = 305;
    let currentPosition = 1;
    let posCount=0;
    let cartCount=0;
    
    var $watch=$('img.watch');

    function slide($element, direction) {
        const totalImages = $element.find('img').length;

        if (direction === 'next') {
            currentPosition -= width;
            posCount++;
            if (posCount === totalImages) {
                currentPosition = 0;
                posCount = 0;
            }
        } else if (direction === 'prev') {
            currentPosition += width;
            posCount--;
            if (posCount < 0) {
                currentPosition = -width * (totalImages - 1);
                posCount = totalImages - 1;
            }
        }

        $element.animate({ "marginLeft": currentPosition }, 2000);
    }


    $(".next").click(evt => {
        slide($("ul.firstProduct"), 'next');
    });

    $(".prev").click(evt => {
        slide($("ul.firstProduct"), 'prev');
    });

    $("#next2").click(evt => {
        slide($("ul.secondProduct"), 'next');
    });

    $("#prev2").click(evt => {
        slide($("ul.secondProduct"), 'prev');
    });

    $("#next3").click(evt => {
        slide($("ul.thirdProduct"), 'next');
    });

    $("#prev3").click(evt => {
        slide($("ul.thirdProduct"), 'prev');
    });

    $("#next4").click(evt => {
        slide($("ul.fourthProduct"), 'next');
    });

    $("#prev4").click(evt => {
        slide($("ul.fourthProduct"), 'prev');
    });


    $("#menu li,a").mouseenter(function(){
        $(this).css("border-bottom", "2px solid white");

    });
    
    $("#menu li,a").mouseleave(function(){
        $(this).css("border-bottom", "none");

    });
    
    

   
    
    

   
   
   

    $(".cart").mouseenter(function(){

        $(this).css("background-color","black");
    });

    $(".cart").mouseleave(function(){

        $(this).css("background-color","transparent");
    });

    $("#first").mouseenter(evt=>{
        $(".prev,.next").css("display","block");

    });
    
    $("#first").mouseleave(evt=>{
        $(".prev,.next").css("display","none");

    });

    $("#second").mouseenter(evt=>{
        $("#prev2,#next2").css("display","block");

    });
    
    $("#second").mouseleave(evt=>{
        $("#prev2,#next2").css("display","none");

    });

    $("#third").mouseenter(evt=>{
        $("#prev3,#next3").css("display","block");

    });
    
    $("#third").mouseleave(evt=>{
        $("#prev3,#next3").css("display","none");

    });

    $("#fourth").mouseenter(evt=>{
        $("#prev4,#next4").css("display","block");

    });
    
    $("#fourth").mouseleave(evt=>{
        $("#prev4,#next4").css("display","none");

    });
  

    $('.listCart').on('click', '.removeItem', function(evt) {
        $(this).closest('.item').remove(); // Remove the closest item element from the cart
        updateTotalPrice(); // Update total price after item removal
        updateCartCount(); // Update the cart count if needed
    });
    
    // Update cart count function
    function updateCartCount() {
        const itemsInCart = $('.listCart .item').length;
        $(".cart-number").text(itemsInCart);
        if (itemsInCart === 0) {
            $(".cart-number").hide(); // Hide the cart count if the cart is empty
        }
    }
    

    $(".cart").click(evt => {
        cartCount++;
        $(".cart-number").text(cartCount);
        $(".cart-number").show();
    
        const $parentDiv = $(evt.target).parent();
        const itemName = $parentDiv.find('.product-name').text();
        const itemImage = $parentDiv.find('img').attr('src');
        const itemPrice = $parentDiv.find('.price').text();
    
        const $newCartItem = $('<div class="item">' +
            '<div class="image">' +
            `<img src="${itemImage}">` +
            '</div>' +
            '<div class="name">' +
            `${itemName}` +
            '</div>' +
            '<div class="quantity">' +
            '<button class="minus">-</button>' +
            '<span>1</span>' +
            '<button class="plus">+</button>' +
            '</div>' +
            '<div class="price">' +
            `${itemPrice}` +
            '</div>' +
            
            '<button class="removeItem">Remove</button>'+
            '</div>'
        );
    
        $('.listCart').append($newCartItem);
    

        function calculateTotalPrice() {
            let totalPrice = 0;
        
            $('.listCart .item').each(function() {
                const priceString = $(this).find('.price').text().replace(/[^0-9.]/g, ''); 
                console.log("Price String:", priceString);
        
                // Check if priceString is not an empty string
                if (priceString.trim() !== '') {
                    const priceNumber = parseFloat(priceString);
                    totalPrice += priceNumber;
                }
            });
        
            return totalPrice.toFixed(2);
        }

        
    
        const totalPrice = calculateTotalPrice();
        $('.total-price').text(`Total: $${totalPrice}`);
    

            
       
    });

    $('.listCart').on('click', '.removeItem', function(evt) {
        $(this).closest('.item').remove(); // Remove the closest item element from the cart
        updateTotalPrice(); // Update total price after item removal
        updateCartCount(); // Update the cart count if needed
    });

    
    

    function updateTotalPrice() {
        let totalPrice = 0;
    
        $('.listCart .item').each(function() {
            const priceString = $(this).find('.price').text().replace(/[^0-9.]/g, '');
            const quantity = parseInt($(this).find('.quantity span').text());
    
            if (priceString.trim() !== '') {
                const priceNumber = parseFloat(priceString);
                totalPrice += priceNumber * quantity; // Multiply price by quantity
            }
        });
    
        $('.total-price').text(`Total: $${totalPrice.toFixed(2)}`);
    }

    
    
   


    $('.listCart').on('click', '.plus', function(evt) {
        const $quantitySpan = $(evt.target).siblings('span');
        let quantity = parseInt($quantitySpan.text());
        quantity++;
        $quantitySpan.text(quantity);
        updateTotalPrice(); // Update total price after quantity change
    });
    
    $('.listCart').on('click', '.minus', function(evt) {
        const $quantitySpan = $(evt.target).siblings('span');
        let quantity = parseInt($quantitySpan.text());
        if (quantity > 1) {
            quantity--;
            $quantitySpan.text(quantity);
            updateTotalPrice(); // Update total price after quantity change
        }
    });
    $("#cart").click(evt=>{
        
        $(".cartTab").css("inset","0 0 0 auto");
    });

    $(".close").click(evt=>{

        $(".cartTab").css("inset","0 -400px 0 auto");
    });

   

});