<?php
$mydb=new mysqli("localhost","root","","user_info");

if($mydb->connect_errno)
{
    echo "Failed to connect to database". $mydb->connect_error;
}
$queryFetch = "SELECT * FROM product_table";
$result = mysqli_query($mydb, $queryFetch);
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Welcome</title>
        <link href="main.css" rel="stylesheet">
        <link rel="icon" href="images/Suleiman Jibril.png">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <header>
            <h1 id="logo">SJ SHOPS</h1>
           

            <ul id="menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="featured.html">New</a></li>
                <li><a href="Login/index.php">Login</a></li>
                <div id="cart-container">
                    <li><img id="cart" src="images/cart.png"></li>
                    <p class="cart-number">0</p>
                </div>
            </ul>
        </header>

            <div id="first">
                
                <h1 class="message">CHECK OUT OUR WATCH COLLECTION</h1>
                <button class="prev">&laquo;</button>
                <ul class="firstProduct">
                    <div>
                        <li><img class="watch"src="images/watch.jpeg"></li>
                        <span class="product-name">Luminor Panerai</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="watch"src="images/watch2.jpeg"></li>
                        <span class="product-name">Luminor Submersible</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="watch"src="images/watch3.jpeg"></li>
                        <span class="product-name">Luminor 200 meter</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="watch"src="images/watch4.jpeg"></li>
                        <span class="product-name">Breding Premier</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="watch"src="images/watch5.jpeg"></li>
                        <span class="product-name">Breitling Chronometer Certifie</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="watch"src="images/watch6.jpeg"></li>
                        <span class="product-name">AVI-8</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                </ul>
                <button class="next">&raquo;</button>   
            </div>

            <div id="second">
                
                <h1 class="message">CHECK OUT OUR HOODIE COLLECTION</h1>
                <button id="prev2">&laquo;</button>
                <ul class="secondProduct">
                    <div>
                        <li><img class="hoodie"src="images/hoodie1.jpg"></li>
                        <span class="product-name">Guys cartoon graphic zip up hoodie</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="hoodie"src="images/hoodie2.jpg"></li>
                        <span class="product-name">Addidas men khaki hoodie</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="hoodie"src="images/hoodie3.jpg"></li>
                        <span class="product-name">Addidas blue hoodie</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="hoodie"src="images/hoodie4.jpg"></li>
                        <span class="product-name">Nike Sports hoodie</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="hoodie"src="images/hoodie5.jpg"></li>
                        <span class="product-name">Puma hoodie</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="hoodie"src="images/hoodie6.jpg"></li>
                        <span class="product-name">Addidas boys hoodie</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                </ul>
                <button id="next2">&raquo;</button>
            </div>

            <div id="third">
                <h1 class="message">CHECK OUT OUR SHOE COLLECTION</h1>
                <button id="prev3">&laquo;</button>
                <ul class="thirdProduct">
                    <div>
                        <li><img class="shoes" src="images/shoe1.jpg"></li>
                        <span class="product-name">Men's white leather sneakers</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="shoes" src="images/shoe2.jpg"></li>
                        <span class="product-name">Adidad Basketball shoes</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="shoes" src="images/shoe3.jpg"></li>
                        <span class="product-name">Timberland Boots</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="shoes" src="images/shoe4.jpg"></li>
                        <span class="product-name">Nike Air jordan 1</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="shoes" src="images/shoe5.jpg"></li>
                        <span class="product-name">Nike Jordan 1 low</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="shoes" src="images/shoe6.jpg"></li>
                        <span class="product-name">Casual leather sneakers</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>
                </ul>
                <button id="next3">&raquo;</button>
            </div>

            <div id="fourth">
                <h1 class="message" id="winter">CHECK OUT OUR  WINTER COLLECTION</h1>
                <button id="prev4">&laquo;</button>
                <ul class="fourthProduct">
                    <div>
                        <li><img class="jacket" src="images/jacket1.jpg"></li>
                        <span class="product-name">Ouku men's winter coat</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="jacket" src="images/jacket2.jpg"></li>
                        <span class="product-name">Etsy men's winter fleece jacket</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="jacket" src="images/jacket3.jpg"></li>
                        <span class="product-name">Meetfanshop men's spring and autumn casual jacket</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="jacket" src="images/jacket4.jpg"></li>
                        <span class="product-name">Dhgate men streetwear</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="jacket" src="images/jacket5.jpg"></li>
                        <span class="product-name">Price tug jacket men</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="jacket" src="images/jacket6.jpg"></li>
                        <span class="product-name">Cosfine puffer jacket</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="jacket" src="images/jacket7.jpg"></li>
                        <span class="product-name">Legendary white tails women's parka coat</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="jacket" src="images/jacket8.jpg"></li>
                        <span class="product-name">Fashion queen winter coat</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="jacket" src="images/jacket9.jpg"></li>
                        <span class="product-name">Zalando winter jacket</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="jacket" src="images/jacket10.jpg"></li>
                        <span class="product-name">Wellensteyn winter jacket</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>
                </ul>

                <button id="next4">&raquo;</button>
            </div>

            <div class="cartTab">
                <h1>Shopping Cart</h1>
                
                <div class="listCart">
                    <div class="item">
                       
                    </div>
                </div>
                <div class="total">
                    <h1>Total:</h1>
                    <span class="total-price">$0.00</span>
                </div>
                <div class="btn">
                    <button class="close">Close</button>
                    <button class="checkout">Check out</button>
                </div>
                <div class="clear">
               
             
                </div>
            </div>
        <script src="code.jquery.com_jquery-3.7.1.js"></script>
        <script src="main.js"></script>
    </body>
</html>