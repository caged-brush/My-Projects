<?php
include 'Model/Model.php';
include 'View/Views.php';
include 'Controller/Controller.php';

$model=new Model();
$view=new View();
$controller=new Controller($model,$view);


$view->renderNew();
?>