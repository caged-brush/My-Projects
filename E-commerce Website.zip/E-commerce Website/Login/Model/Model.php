<?php
class Model{
    private $mydb;
    public function __construct(){
        $this->mydb=new mysqli("localhost","root","","user_info");

        if($this->mydb->connect_errno){
            echo "Failed to connect to MYSQL: " . $this->mydb->connect_error;
            exit();
        }
    }

    public function isAuthenticated()
    {
        return isset($_SESSION['user']);
    }

    public function getUsername()
    {
        return isset($_SESSION['user']['Name']) ? $_SESSION['user']['Name'] :'';
    }

    public function authenticateUser($email,$password)
    {
        $select_query="SELECT * FROM personal_info WHERE email='$email' AND  password= '$password'";
        $select_result=mysqli_query($this->mydb,$select_query);
        $row=mysqli_fetch_assoc($select_result);
        return $row;
    }

    public function registerUser($fname,$lname,$email,$phone,$password)
    {
        $insert_query= "INSERT INTO personal_info (`firstname`,`lastname`,`email`,`phoneNumber`,`password`)
        VALUES ('$fname','$lname','$email','$phone','$password')";
        $insert_result=mysqli_query($this->mydb,$insert_query);
        return $insert_result;
    }

    public function getErrorMessage()
    {
        return $this->mydb->error;
    }
}

?>