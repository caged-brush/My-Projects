<html>
<head>
    <style>
        label{
            min-width: 120px;
            display: inline-block;
            text-align: right;
            padding-right: 5px;
        }
        .success{
            color: green;
        }
        .failure{
            color: red;
        }
    </style>
</head>
<body>

