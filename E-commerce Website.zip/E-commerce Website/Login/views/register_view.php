<html>
    <head>
        <title>Sign up</title>
       <style>
            @font-face 
            {
                font-family:listFont;
                src: url(Titillium_Web/TitilliumWeb-Regular.ttf);
            }
            
            .success
            {
                background-color: green;
                color: black;

            }

            .failure
            {
                background-color: red;
                color: black;
            }

            body
            {
               
                
               text-align: center;
            }

            #submit
            {
                
                border: 0.5px solid #ccc;
                background-color: rgba(169, 169, 169, 0.7);
                height: 50px;
                width: 200px;
                color:white;
                cursor: pointer;
            }

            form
            {
                margin-top: 100px;
            }

            .information
            {
                 
                border:none ;
                background: none;
                border-bottom: 1px solid black;
                width: 30%;
                padding-right: 30px;
            }

            .information:focus {
                outline: none;
                
            }

            .label 
            {
                width: 150px; 
                text-align: left; 
                margin-right: 225px; 
                display: inline-block; 
                color: grey;
            }
            .heading
            {
                position: relative;
                top: 60px;
            }
            #caption
            {   
                font-family: listFont;
                font-size: 30px;

            }

            #first-password
            {
                cursor: pointer;
                margin-left: 350px;
            }

            #confirm
            {
                cursor: pointer;
                margin-left: 350px;
            }

            input
            {
                font-size: 20px;
            }

            header 
            {
                position: fixed; /* Set the header to a fixed position */
                top: 0; /* Stick it to the top of the viewport */
                left: 0; /* Stick it to the left side of the viewport */
                right: 0; /* Stretch it to the full width of the viewport */
                padding: 9px;
                display: flex;
                justify-content: right;
                align-items: center;
            
            }

            li
            {
                margin-right: 40px;
                font-size: 18px;
                list-style: none;
                text-decoration: none;
                font-family: listFont;
            }

            li a 
            {
                text-decoration: none; 
                color: black; 
            }

          

       </style>
       <link rel="icon" href="images/Suleiman Jibril.png">
    </head>

    <body>

        <header>
            <ul>
                <li><a href="index.php">Login</a></li>
            </ul>
        </header>

        <div class="heading">
            <h1 id="caption">Create Your Account</h1>
        </div>

        <form action="signupIndex.php" method="POST">
            <div class="info">
                <div class="label-container">
                    <label class="label">First name</label>
                </div>
                <br>
                <input class="information" type="text" name="fname" size="30" required>
            </div>

            <br>

            <div class="info">
                <div class="label-container">
                    <label class="label">Last Name</label>
                </div>
                <br>
                <input class="information" type="text" name="lname" size="30" required>
            </div>

            <br>

            <div class="info">
                <div class="label-container">
                    <label class="label">E-mail</label>
                </div>
                <br>
                <input class="information" type="email" id="email" name="email" size="30" required>
            </div>

            <br>

            <div class="info">
                <div class="label-container">
                    <label class="label">Phone Number</label>
                </div>
                <br>
                <input class="information" id="num" type="tel" name="phone" size="30" required>
            </div>

            <br>

            <div class="info">
                <div class="label-container">
                    <label class="label">Password</label>
                </div>
                <img id="first-password" src="views/passwordImages/show.png" alt="Show Password">
                <br>
                <input class="information" id="password" type="password" name="password" size="30" required>
            </div>

            <br>

            <div class="info">
                <div class="label-container">
                    <label class="label">Confirm Password</label>
                </div>
                <img id="confirm" src="views/passwordImages/show.png" alt="Show Password">
                <br>
                <input class="information" id="confirm-password" type="password" name="confirm-password" size="30" required>
                <span> </span>
            </div>

            <br>

            <div class="info">
                <input id="submit" type="submit" name="submit" value="Submit">
            </div>
            
        </form>
        <script src="views/javascript/code.jquery.com_jquery-3.7.1.js"></script>
        <script src="views/javascript/signup.js"></script>
    </body>
</html>