<?php
$mydb=new mysqli("localhost","root","","user_info");

if($mydb->connect_errno)
{
    echo "Failed to connect to database". $mydb->connect_error;
}
$queryFetch = "SELECT * FROM product_table";
$result = mysqli_query($mydb, $queryFetch);
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Welcome</title>
        <link href="views/style/main.css" rel="stylesheet">
        <link rel="icon" href="views/images/Suleiman Jibril.png">
        <link href="https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Titillium+Web:wght@300;400;700&display=swap" rel="stylesheet">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <header>
            <h1 id="logo">SJ SHOPS</h1>
           
            <ul id="menu">
                <li><a href="#">Home</a></li>
                <li><a href="featuredIndex.php">New</a></li>
                <li><a href="logoutIndex.php">Logout</a></li>
                <div id="cart-container">
                    <li><img id="cart" src="views/images/cart.png"></li>
                    <p class="cart-number">0</p>
                </div>
            </ul>
        </header>

            <div id="first">
                
                <h1 class="message">CHECK OUT OUR WATCH COLLECTION</h1>
                <button class="prev">&laquo;</button>
                <ul class="firstProduct">
                    <div>
                        <li><img class="watch"src="views/images/watch.jpeg"></li>
                        <span class="product-name">Luminor Panerai</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="watch"src="views/images/watch2.jpeg"></li>
                        <span class="product-name">Luminor Submersible</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="watch"src="views/images/watch3.jpeg"></li>
                        <span class="product-name">Luminor 200 meter</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="watch"src="views/images/watch4.jpeg"></li>
                        <span class="product-name">Breding Premier</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="watch"src="views/images/watch5.jpeg"></li>
                        <span class="product-name">Breitling Chronometer Certifie</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="watch"src="views/images/watch6.jpeg"></li>
                        <span class="product-name">AVI-8</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                </ul>
                <button class="next">&raquo;</button>   
            </div>

            <div id="second">
                
                <h1 class="message">CHECK OUT OUR HOODIE COLLECTION</h1>
                <button id="prev2">&laquo;</button>
                <ul class="secondProduct">
                    <div>
                        <li><img class="hoodie"src="views/images/hoodie1.jpg"></li>
                        <span class="product-name">Guys cartoon graphic zip up hoodie</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="hoodie"src="views/images/hoodie2.jpg"></li>
                        <span class="product-name">Addidas men khaki hoodie</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="hoodie"src="views/images/hoodie3.jpg"></li>
                        <span class="product-name">Addidas blue hoodie</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="hoodie"src="views/images/hoodie4.jpg"></li>
                        <span class="product-name">Nike Sports hoodie</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="hoodie"src="views/images/hoodie5.jpg"></li>
                        <span class="product-name">Puma hoodie</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="hoodie"src="views/images/hoodie6.jpg"></li>
                        <span class="product-name">Addidas boys hoodie</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                </ul>
                <button id="next2">&raquo;</button>
            </div>

            <div id="third">
                <h1 class="message">CHECK OUT OUR SHOE COLLECTION</h1>
                <button id="prev3">&laquo;</button>
                <ul class="thirdProduct">
                    <div>
                        <li><img class="shoes" src="views/images/shoe1.jpg"></li>
                        <span class="product-name">Men's white leather sneakers</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="shoes" src="views/images/shoe2.jpg"></li>
                        <span class="product-name">Adidas Basketball shoes</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="shoes" src="views/images/shoe3.jpg"></li>
                        <span class="product-name">Timberland Boots</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="shoes" src="views/images/shoe4.jpg"></li>
                        <span class="product-name">Nike Air jordan 1</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="shoes" src="views/images/shoe5.jpg"></li>
                        <span class="product-name">Nike Jordan 1 low</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="shoes" src="views/images/shoe6.jpg"></li>
                        <span class="product-name">Casual leather sneakers</span>
                        <br>
                        <br>
                        <span class="price">$99.99</span>
                        <button class="cart">Add to Cart</button>
                    </div>
                </ul>
                <button id="next3">&raquo;</button>
            </div>

            <div id="fourth">
                <h1 class="message" id="winter">CHECK OUT OUR  WINTER COLLECTION</h1>
                <button id="prev4">&laquo;</button>
                <ul class="fourthProduct">
                    <div>
                        <li><img class="jacket" src="views/images/jacket1.jpg"></li>
                        <span class="product-name">Ouku men's winter coat</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="jacket" src="views/images/jacket2.jpg"></li>
                        <span class="product-name">Etsy men's winter fleece jacket</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="jacket" src="views/images/jacket3.jpg"></li>
                        <span class="product-name">Meetfanshop men's spring and autumn casual jacket</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="jacket" src="views/images/jacket4.jpg"></li>
                        <span class="product-name">Dhgate men streetwear</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="jacket" src="views/images/jacket5.jpg"></li>
                        <span class="product-name">Price tug jacket men</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="jacket" src="views/images/jacket6.jpg"></li>
                        <span class="product-name">Cosfine puffer jacket</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="jacket" src="views/images/jacket7.jpg"></li>
                        <span class="product-name">Legendary white tails women's parka coat</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="jacket" src="views/images/jacket8.jpg"></li>
                        <span class="product-name">Fashion queen winter coat</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="jacket" src="views/images/jacket9.jpg"></li>
                        <span class="product-name">Zalando winter jacket</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>

                    <div>
                        <li><img class="jacket" src="views/images/jacket10.jpg"></li>
                        <span class="product-name">Wellensteyn winter jacket</span>
                        <br>
                        <br>
                        <span class="price" id="jacketPrice">$99.99</span>
                        <button class="cart" id="cartButton">Add to Cart</button>
                    </div>
                </ul>

                <button id="next4">&raquo;</button>
            </div>

            <div class="cartTab">
                <h1>Shopping Cart</h1>
                
                <div class="listCart">
                    <div class="item">
                       
                    </div>
                </div>
                <div class="total">
                    <h1>Total:</h1>
                    <span class="total-price">$0.00</span>
                </div>
                <div class="btn">
                    <button class="close">Close</button>
                    <button class="checkout">Check out</button>
                </div>
                <div class="clear">
               
             
                </div>
            </div>
        <script src="views/javascript/code.jquery.com_jquery-3.7.1.js"></script>
        <script src="views/javascript/main.js"></script>
    </body>
</html>