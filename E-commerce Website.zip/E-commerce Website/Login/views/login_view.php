<html>
    <head>
        <title>Login</title>
       <style>
            @font-face 
            {
                font-family:listFont;
                src: url(Titillium_Web/TitilliumWeb-Regular.ttf);
            }
           
            .success
            {
                background-color: green;
                color: black;

            }

            .failure
            {
                background-color: red;
                color: black;
            }

            body
            {
               
                
               text-align: center;
            }

            #submit
            {
                
                border: 0.5px solid #ccc;
                background-color: rgba(169, 169, 169, 0.7);
                height: 50px;
                width: 200px;
                color:white;
                cursor: pointer;
            }

            form
            {
                margin-top: 100px;
            }

            .information
            {
                 
                border:none ;
                background: none;
                border-bottom: 1px solid black;
                width: 30%;
                padding-right: 30px;
            }

            .information:focus {
                outline: none;
                
            }

            .label 
            {
                width: 150px; 
                text-align: left; 
                margin-right: 225px; 
                display: inline-block; 
                color: grey;
            }
            .heading
            {
                position: relative;
                top: 60px;
            }
            #caption
            {   
                font-family: listFont;
                font-size: 30px;

            }

            #show-password
            {
                cursor: pointer;
                margin-left: 350px;
            }

            input
            {
                font-size: 20px;
            }

            header 
            {
                position: fixed; /* Set the header to a fixed position */
                top: 0; /* Stick it to the top of the viewport */
                left: 0; /* Stick it to the left side of the viewport */
                right: 0; /* Stretch it to the full width of the viewport */
                padding: 9px;
                display: flex;
                justify-content: right;
                align-items: center;
            
            }

            li
            {
                margin-right: 40px;
                font-size: 18px;
                list-style: none;
                text-decoration: none;
                font-family: listFont;
            }

            li a 
            {
                text-decoration: none; 
                color: black; 
            }
       </style>
       <link rel="icon" href="images/Suleiman Jibril.png">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>

    <body>

        <header>
            <ul>
                <li><a href="signupIndex.php">Create Account</a></li>
            </ul>
        </header>
        <div class="heading">
            <h1 id="caption">Login To Your Account</h1>
        </div>

        <form action="loginIndex.php" method="POST">
            <div class="info">
                <div class="label-container">
                    <label class="label">E-mail</label>
                </div>
                <br>
                <input class="information" type="email" name="email" size="30">
            </div>

            <br>

            <div class="info">
                <div class="label-container">
                    <label class="label">Password</label>
                </div>
                <img id="show-password" src="views/images/show.png" alt="Show Password">
                <br>
                <input class="information" id="password" type="password" name="password" size="30">
            </div>

            <br>

            <div class="info">
                <input id="submit" type="submit" name="submit" value="Login">
            </div>
            
        </form>
        <script src="views/javascript/code.jquery.com_jquery-3.7.1.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
        <script src="views/javascript/login.js"></script>
    </body>
</html>