"use script";

$(document).ready(()=>{
    
    $("#submit").mouseenter(function(){
        $(this).css("background-color","black");
        $(this).css("color","white");

    });

    $("#submit").mouseleave(function(){
        $(this).css( "background-color", "rgba(169, 169, 169, 0.7)");
    });

    $("li,a").mouseenter(function(){
        $(this).css("border-bottom", "2px solid black");

       
    });
    
    $("li,a").mouseleave(function(){
        $(this).css("border-bottom", "none");
       
    });

    $("#show-password").click(function(){
        var $image = $(this);

        if ($image.attr("src") === "views/javascript/jsimages/noshow.png") {
            $image.attr("src", "views/javascript/jsimages/show.png");
        } else {
            $image.attr("src", "views/javascript/jsimages/noshow.png");
        }
    });

    $("#show-password").click(function(){
        var $pass=$("#password");

        if($pass.attr("type")==='text')
        {
            $pass.prop("type","password");
        } 

        else 
        {
            $pass.prop("type", "text");
        }
    });

});