<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="views/style/featured.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
    <title>New</title>
</head>
<body>
    <header>
        <h1 id="new">NEW PRODUCTS</h1>
        <ul id="menu">
            <li><a href="index.php">Home</a></li>
            <li><a href="featuredIndex.php">New</a></li>
            <li><a href="logoutIndex.php">Logout</a></li>
            <div id="cart-container">
                <li><img id="cart" src="views/images/cart.png"></li>
                <p class="cart-number">0</p>
            </div>
        </ul>
    </header>
    <section class="container-fluid">
        <div>
            <div class="image">
                <img src="views/images/ws1.jpg" alt="">
            </div>
            <div class="text">
                <h2>Franck Muller - Haute Horlogerie Watches</h2>
                <p>50% Discount on first 10 pieces sold</p>
            </div>
        </div>
    </section>
    <section class="container-fluid">
        <div>
            <div class="image">
                <img src="views/images/watch2.jpg" alt="">
            </div>
            <div class="text">
                <h2>Richard Mille - RM056-01 Limited Edition</h2>
                <p>50% Discount on first 30 pieces sold</p>
            </div>
        </div>
    </section>
    <section class="container-fluid">
        <div>
            <div class="image">
                <img src="views/images/phone2.jpeg" alt="">
            </div>
            <div class="text">
                <h2>BRAND NEW IPHONE 15 PRO MAX</h2>
                <p>10% Discount on first 50 pieces sold</p>
            </div>
        </div>
    </section>
</body>
</html>