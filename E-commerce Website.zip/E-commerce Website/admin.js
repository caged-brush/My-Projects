"use script"

$(document).ready(()=>{

    

    $("#submit").mouseenter(function(){
        $(this).css("background-color","black");
        $(this).css("color","white");

    });

    $("#submit").mouseleave(function(){
        $(this).css( "background-color", "rgba(169, 169, 169, 0.7)");
    });

    $("li,a").mouseenter(function(){
        $(this).css("border-bottom", "2px solid white");

       
    });
    
    $("li,a").mouseleave(function(){
        $(this).css("border-bottom", "none");
       
    });

    $("#success-message").fadeIn(1000);

    // Automatically hide the success message after 3 seconds (3000 milliseconds)
    setTimeout(function() {
        $("#success-message").fadeOut(1000);
    }, 3000);
});    