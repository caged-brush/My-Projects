<?php
//*********** CREATING A DATABASE CONNECTION********

//$mysqli = new mysqli("localhost","my_user","my_password","my_db")
$mydb = new mysqli("localhost","root","","demo_database");

// Check connection
if ($mydb -> connect_errno) 
{
  echo "Failed to connect to MySQL: " . $mydb -> connect_error;
  exit();
}
//************ INSERTING VALUES INTO DATABASE***********
//The isset() function checks whether a variable is set, which means that it has to be declared and is not NULL. This function returns true if the variable exists and is not NULL, otherwise it returns false

if(isset($_POST['insert'])) //value coming from form on the click of Insert button
{
    //insert data using MySQL query: 
    //INSERT INTO TABLE_NAME(COLUMN_NAME 1, COLUMN_NAME 2...COLUMN_NAME N) VALUES (VALUE 1, VALUE 2 .... VALUE N)
    
    $insert_query = "INSERT INTO information (`Name`, `Contact`, `Email`, `Password`) VALUES ('".$_POST['name']."','".$_POST['contact']."','".$_POST['email']."', '".$_POST['password']."')";

    // print $insert_query; die;  -->  INSERT INTO information (`Name`, `Contact`, `Email`, `Password`) VALUES ('Mike','9999955555','admin@gmail.com', 'password')
    
    $insert_result = mysqli_query($mydb,$insert_query);
    

    //insert_id Retrieves the ID generated for an AUTO_INCREMENT column by the previous query.
    $last_id = $mydb->insert_id; // to get last id of row
    //print $last_id; die;
    // image upload starts here

    if(isset($_FILES['fileToUpload'])){
        
        $target_dir = "uploads/";       //uploads/
        $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);         //uploads/image.jpg
        //The base name function is used to extract the filename from given path
        
       // print_r(basename($_FILES["fileToUpload"]["name"])); die; //filename (image.jpg)
        //print '<pre>';print_r($_FILES); die;

        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION)); //The pathinfo is used to retrieve the information about file. PATH_ExXTENSION constant will give extension of the file
    //    print_r($imageFileType); die; 
        // Check if image file is a actual image or fake image
        
        if(isset($_POST["submit"])) {
        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
         if($check !== false) 
         {
            echo "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } 
        else 
        {
            echo "File is not an image.";
            $uploadOk = 0;
        }
        }
        //die;
        // Check if file already exists
        if (file_exists($target_file)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
        }
        //die;
        // Check file size
        if ($_FILES["fileToUpload"]["size"] > 5000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
        }
        //die;
        // Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
        // if everything is ok, try to upload file
        } 
        else 
        {
            $file_name = md5(time()); //generates a unique file name for the uploaded image by using the current timestamp (time) and applying MD5 hash function

        //   print"<pre>"; print_r($file_name); die;
        $image_final_name = $target_dir.$file_name.'.'.$imageFileType;
        //print"<pre>"; print_r($image_final_name); die;
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],$image_final_name)) {
            
            echo "The file ". htmlspecialchars(basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";

            
            $image_update_query = "UPDATE `information` SET `image`='".$image_final_name."' WHERE ID =".$last_id;
   

            $insert_result = mysqli_query($mydb,$image_update_query);

        } else {
            echo "Sorry, there was an error uploading your file.";
        }
        }
    }

    // image upload ends

    if($insert_result)
    {
        print "<p class='success'>Insert successfully!</p>";
    }
    else
    {
        print "<p class='failure'>Something went wrong</p>";
    }
}

// TO DELETE DATA FROM DATABASE 

if(isset($_POST['delete']))
{
    //delete the record using MySQL DELETE query
    //DELETE FROM TABLE_NAME WHERE CONDITION

    $get_query = "select image from information where ID=".$_POST['ID'];
    $get_result = mysqli_query($mydb,$get_query);

    $row = mysqli_fetch_array($get_result);
    //print $row['image']; die;
    unlink($row['image']); //unlink - deletes a file
    
    
    $delete_query = "delete from information where ID=".$_POST['ID'];

    //print $delete_query; --> delete from information where ID=6
    
    //storing the query result into delete_query
    $delete_result = mysqli_query($mydb,$delete_query);
    
    
    //checking if records get deleted or not
    if($delete_result)
    {
        echo "<p class='success'>Record deleted successfully</p>";
    }else
    {
        echo "<p class='failure'>Something went wrong</p>";
    }
}

//to display the records from database
//use SQL SELECT query
// SELECT * FROM TABLE_NAME
$queryFetch = "select * from information";
$result = mysqli_query($mydb,$queryFetch);
?>

<html>
<head>
    <style>
        label{
            min-width: 120px;
            display: inline-block;
            text-align: right;
            padding-right: 5px;
        }
        .success{
            color: green;
        }
        .failure{
            color: red;
        }
    </style>
</head>
<body>
<div><p><b>Please complete form to register</b></p></div>

<form action="registration.php" method="POST" enctype="multipart/form-data">
    <p>
        <label>Name:</label>
        <input type="text" name="name" size="30">
    </p>
    <p>
        <label>Contact Number:</label>
        <input type="phone" name="contact" size="30">
    </p>
    <p>
        <label>Email:</label>
        <input type="email" name="email" size="30">
    </p>
    <p>
        <label>Password:</label>
        <input type="password" name="password" size="30">
    </p>
    <p>
        <label>Profile Image:</label>
        <input type="file" name="fileToUpload" size="30">
    </p>
    <input type="submit" name="insert" value="Insert">
</form>
</div>

<!--to perform deletion-->

<table border="2">
    <tr>
    <th>Name</th>
    <th>Contact</th>
    <th>Email</th>
    <th>Password</th>
    <th>Image</th>
    <th>Action</th>
    </tr>

    <?php
    //to select (fetch) values from the database and display it
    //mysqli_fetch_array()
    //Fetches one row of data from the result set and returns it as an array. Each subsequent call to this function will return the next row within the result set, or null if there are no more rows.

    while($row = mysqli_fetch_array($result)){  
        //print '<pre>';print_r($row);print '</pre>';
        ?>
        <tr>
            <td><?php echo $row['Name']; ?> </td>
            <td><?php echo $row['Contact']; ?> </td>
            <td><?php echo $row['Email']; ?> </td>
            <td><?php echo $row['Password']; ?> </td>
            <td>
                <?php
                if($row['image'] != null){

                ?>
                <img style="width: 100px;" src="<?php echo $row['image']; ?>" />
<?php
                }else{
                    print 'No image';
                }
?>

             </td>
            <td>
            <form action="registration.php" method="POST">
                <input type="hidden" name="ID" value="<?php echo $row['ID']; ?>">
                <input type="submit" name="delete" value="Delete">
            </form>

            </td>
        </tr>
    <?php  }
    ?>

</table>
</body>
    </html>
