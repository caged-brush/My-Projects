<?php
$mydb = new mysqli("localhost", "root", "", "user_info");

if ($mydb->connect_errno) {
    echo "Failed to connect to database" . $mydb->connect_error;
}

if (isset($_POST['search_submit'])) {
    $search_term = mysqli_real_escape_string($mydb, $_POST['search_term']);
    // Modify your SQL query to include a WHERE clause for searching
    $queryFetch = "SELECT * FROM product_table WHERE product_name LIKE '%$search_term%'";
    $result = mysqli_query($mydb, $queryFetch);
} else {
    // Default query to fetch all products if no search is performed
    $queryFetch = "SELECT * FROM product_table";
    $result = mysqli_query($mydb, $queryFetch);
}
?>

<html>
<head>
    <title>Result</title>
</head>
<body>
    <ul class="firstProduct">
        <?php
        if(mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<div>";
                echo "<span class='product-name'>{$row['product_name']}</span>";
                echo "<br><br>";
                $imageName = $row['product_name'];
                $imagePath = "images/$imageName.jpg"; // Path to your images folder
                if(file_exists($imagePath)) {
                    echo "<img class='product-image' src='$imagePath' alt='{$row['product_name']}'>";
                } else {
                    echo "<img class='product-image' src='default_image.jpg' alt='Default Image'>";
                    // Use a default image if the specific product image doesn't exist
                }
                echo "<span class='price'>$99.99</span>"; // Replace this with the actual price from your database
                echo "<button class='cart'>Add to Cart</button>";
                echo "</div>";
            }
        } else {
            echo "<p>No results found.</p>";
        }
        ?>
    </ul>
</body>
</html>
