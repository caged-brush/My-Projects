package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText num1,num2;
    TextView result;
    Button add,subtract,divide,multiply,mod,exponent,percent,factorial,clear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //finds view of XML tags by their ids//
        num1=findViewById(R.id.num1);
        num2=findViewById(R.id.num2);
        add=findViewById(R.id.button);
        result=findViewById(R.id.result);
        subtract=findViewById(R.id.button2);
        divide=findViewById(R.id.button3);
        multiply=findViewById(R.id.button4);
        mod=findViewById(R.id.button5);
        exponent=findViewById(R.id.button6);
        percent=findViewById(R.id.button7);
        factorial=findViewById(R.id.button8);
        clear=findViewById(R.id.button9);

        //functionality for add button
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float res;//declares floating variable to store result
                String resStr;//declares string variable to store result as string

                //changes user input to a string//
                String numStr=num1.getText().toString();
                String numStr2=num2.getText().toString();

                    try//exception handler to ensure user enters a valid input
                    {
                        //changes user input from string to float
                        float numFlt = Float.parseFloat(numStr);
                        float numFlt2 = Float.parseFloat(numStr2);


                        res = numFlt + numFlt2; //adds users input
                        resStr = Float.toString(res);//stores result and changes it to a string
                        result.setText(resStr);//displays result
                    }
                    catch(NumberFormatException e)
                    {
                        //displays a message to user when wrong input is entered//
                        Toast.makeText(MainActivity.this,"Enter two numbers",
                                Toast.LENGTH_SHORT).show();
                    }

            }
        });

        //functionality for subtract button//
        subtract.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float res;
                String resStr;
                String numStr=num1.getText().toString();
                String numStr2=num2.getText().toString();

                    try
                    {
                        float numFlt = Float.parseFloat(numStr);
                        float numFlt2 = Float.parseFloat(numStr2);
                        res = numFlt - numFlt2;
                        resStr = Float.toString(res);
                        result.setText(resStr);
                    }
                    catch (NumberFormatException e)
                    {
                        Toast.makeText(MainActivity.this,"Enter two numbers",
                                Toast.LENGTH_SHORT).show();
                    }
            }
        });

        //functionality for divide button
        divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float res;
                String resStr;
                String numStr=num1.getText().toString();
                String numStr2=num2.getText().toString();

                    try
                    {
                        //displays error when user tries to divide by 0//
                        if (numStr2.equals("0"))
                        {
                            result.setText("Error");
                        }

                        else
                        {
                            float numFlt = Float.parseFloat(numStr);
                            float numFlt2 = Float.parseFloat(numStr2);
                            res = numFlt / numFlt2;
                            resStr = Float.toString(res);
                            result.setText(resStr);
                        }
                    }
                    catch (NumberFormatException e)
                    {
                        Toast.makeText(MainActivity.this,"Enter two numbers",
                                Toast.LENGTH_SHORT).show();
                    }
                }
        });

        //functionality for multiply button
        multiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float res;
                String resStr;
                String numStr=num1.getText().toString();
                String numStr2=num2.getText().toString();

               try
                {
                    float numFlt = Float.parseFloat(numStr);
                    float numFlt2 = Float.parseFloat(numStr2);
                    res = numFlt * numFlt2;
                    resStr = Float.toString(res);
                    result.setText(resStr);
                }
               catch (NumberFormatException e)
               {
                   Toast.makeText(MainActivity.this,"Enter two numbers",
                           Toast.LENGTH_SHORT).show();
               }
            }
        });

        //functionality for MOD button
        mod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float res;
                String resStr;
                String numStr=num1.getText().toString();
                String numStr2=num2.getText().toString();

                try
                {
                    float numFlt = Float.parseFloat(numStr);
                    float numFlt2 = Float.parseFloat(numStr2);
                    res = numFlt % numFlt2;
                    resStr = Float.toString(res);
                    result.setText(resStr);
                }
                catch (NumberFormatException e)
                {
                    Toast.makeText(MainActivity.this,"Enter two numbers",
                            Toast.LENGTH_SHORT).show();
                }

            }
        });

        //functionality of exponent button//
        exponent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float res;
                String resStr;
                String numStr=num1.getText().toString();
                String numStr2=num2.getText().toString();

                try
                {
                    float numFlt = Float.parseFloat(numStr);
                    float numFlt2 = Float.parseFloat(numStr2);
                    res = (float) Math.pow(numFlt, numFlt2);
                    resStr = Float.toString(res);
                    result.setText(resStr);
                }

                catch (NumberFormatException e)
                {
                    Toast.makeText(MainActivity.this,"Enter two numbers",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        //functionality for percent button//
        percent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float res;
                String resStr;
                String numStr=num1.getText().toString();
                String numStr2=num2.getText().toString();

                try
                {
                    float numFlt = Float.parseFloat(numStr);
                    float numFlt2 = Float.parseFloat(numStr2);
                    res = (numFlt / 100) * numFlt2;
                    resStr = Float.toString(res);
                    result.setText(resStr);
                }

                catch (NumberFormatException e)
                {
                    Toast.makeText(MainActivity.this,"Enter two numbers",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        //functionality for factorial button//
        factorial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int res= 1;
                String resStr;
                String numStr=num1.getText().toString();

                try
                {
                    int numFlt = Integer.parseInt(numStr);

                    //returns 1 if user enters 0 because 0!=1//
                    if (numFlt == 0)
                    {
                        result.setText("1");
                    }

                    //returns errors when user enter negative number//
                    if (numFlt < 0)
                    {
                        result.setText("Error");

                    }

                    //calculates factorial of a number
                    else
                    {
                        for (int i = numFlt; i >= 1; i--) {
                            res *= i;
                        }
                        resStr = Integer.toString(res);
                        result.setText(resStr);
                    }

                }
                catch (NumberFormatException e)
                {
                    Toast.makeText(MainActivity.this,"Incorrect input/No input",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        //clears the numbers//
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num1.setText("");
                num2.setText("");
            }
        });

    }
}