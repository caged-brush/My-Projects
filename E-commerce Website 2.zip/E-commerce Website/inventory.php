<?php
$mydb = new mysqli("localhost", "root", "", "user_info");

if ($mydb->connect_errno) {
    echo "Failed to connect to database" . $mydb->connect_error;
    exit();
}

$queryFetch = "SELECT * FROM product_table";
$result = mysqli_query($mydb, $queryFetch);

if(isset($_POST['delete']))
{
    //delete the record using MySQL DELETE query
    //DELETE FROM TABLE_NAME WHERE CONDITION
    //echo "ID to delete: " . $_POST['ID'];

    $delete_query = "delete from product_table where product_id=".$_POST['ID'];
    echo $delete_query; 

    //print $delete_query; --> delete from information where ID=6
    
    //storing the query result into delete_query
    $delete_result = mysqli_query($mydb,$delete_query);
    
    
    //checking if records get deleted or not
    if($delete_result)
    {   echo "<div class='message'>";
        echo "<p id='success-message'>Record deleted successfully</p>";
        echo "</div>";
    }else
    {
        echo "<p id='failure-message'>Something went wrong"  . mysqli_error($mydb) ." </p>";
    }
}
$queryFetch = "select * from product_table";
$result = mysqli_query($mydb,$queryFetch);

?>

<html>
    <head>
        <title>Inventory</title>
        <link href="admin.css" rel="stylesheet">
    </head>
    <body>
        <header>
            <ul id="menu">
                <li><a href="inventory.php">Inventory</a></li>
                <li><a href="admin.php">Dashboard</a></li>
            </ul>
        </header>
        <h1>Inventory</h1>
        <table border="2">
            <tr id="caption">
                <th>Product Name</th>
                <th>Price</th>
                <th>Description</th>
                <th>Quantity</th>
                <th>Action</th>
            </tr>

            <?php
                while ($row = mysqli_fetch_array($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['product_name'] . "</td>";
                    echo "<td>" . $row['price'] . "</td>";
                    echo "<td>" . $row['description'] . "</td>";
                    echo "<td>" . $row['quantity'] . "</td>";
                    echo "<td><form method='post'><input type='hidden' name='ID' value='" . $row['product_id'] . "'>
                    <input type='submit' name='delete' value='Delete'></form></td>";
                    echo "</tr>";
                }
            ?>
           
        </table>
        <script src="code.jquery.com_jquery-3.7.1.js"></script>
        <script src="admin.js"></script>
    </body>
</html>
