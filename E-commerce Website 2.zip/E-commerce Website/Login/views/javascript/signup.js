"use script"

$(document).ready(()=>{

    

    $("#submit").mouseenter(function(){
        $(this).css("background-color","black");
        $(this).css("color","white");

    });

    $("#submit").mouseleave(function(){
        $(this).css( "background-color", "rgba(169, 169, 169, 0.7)");
    });

    $("li,a").mouseenter(function(){
        $(this).css("border-bottom", "2px solid black");

       
    });
    
    $("li,a").mouseleave(function(){
        $(this).css("border-bottom", "none");
       
    });

    $("#first-password").click(function(){
        var $image = $(this);

        if ($image.attr("src") === "views/javascript/jsimages/noshow.png") {
            $image.attr("src", "views/javascript/jsimages/show.png");
        } else {
            $image.attr("src", "views/javascript/jsimages/noshow.png");
        }
    });

    $("#first-password").click(function(){
        var $pass=$("#password");

        if($pass.attr("type")==='text')
        {
            $pass.prop("type","password");
        } 

        else 
        {
            $pass.prop("type", "text");
        }
    });

    $("#confirm").click(function(){
        var $image = $(this);

        if ($image.attr("src") === "views/javascript/jsimages/noshow.png") {
            $image.attr("src", "views/javascript/jsimages/show.png");
        } else {
            $image.attr("src", "views/javascript/jsimages/noshow.png");
        }
    });

    $("#confirm").click(function(){
        var $pass=$("#confirm-password");

        if($pass.attr("type")==='text')
        {
            $pass.prop("type","password");
        } 

        else 
        {
            $pass.prop("type", "text");
        }
    });

    $("#submit").click(evt => {
        var $pass1 = $("#password").val();
        var $pass2 = $("#confirm-password").val();
        var $num=$("#num").val();
        
    
        if ($pass1 !=$pass2) {
            $("#confirm-password").next().text("The passwords do not match");
            evt.preventDefault(); // Prevent form submission
        } else {
            // Clear any previous error messages when passwords match
            $("#confirm-password").next().text("");
        }

        if($pass1.length<8)
        {
            alert("Password must contain 8 characters ");
            evt.preventDefault();
        }
        else if (!(/[0-9]/.test($pass1))) 
        {
            alert("Password must contain at least one number");
            evt.preventDefault();
        } 
        else if (!(/[!@#$%^&*()_+{}\[\]:;<>,.?~\\/-]/.test($pass1)))
        {
            alert("Password must contain at least one special character");
            evt.preventDefault();
        }

        if(isNaN($num))
        {
            alert("Please enter a valid phone number");
            evt.preventDefault();
        }

        else if($num.length!==10)
        {
            alert("Please enter a valid 10 digit phone number");
            evt.preventDefault();
        }

        
    });
    



});