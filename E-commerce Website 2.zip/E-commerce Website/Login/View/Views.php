<?php
class View{
    public function showHeader()
    {
        include 'views/header.php';
    }
    public function showFooter()
    {
        include 'views/footer.php';
    }
    public function renderDashboard($model,$successMessage,$errorMessage)
    {
        include 'views/messages.php';
        include 'views/dashboard.php';
    }

    public function renderNew()
    {
        include 'views/messages.php';
        include 'views/featured.php';  
    }

    public function renderRegister($successMessage,$errorMessage)
    {
        include 'views/messages.php';
        include 'views/register_view.php'; 
    }

    public function renderLogin($successMessage,$errorMessage)
    {
        include 'views/messages.php';
        include 'views/login_view.php';   
    }
}

?>