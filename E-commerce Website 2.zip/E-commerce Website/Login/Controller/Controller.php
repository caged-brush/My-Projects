<?php
session_start();

class Controller{
    private $model;
    private $view;
    private $successMessage="";
    private $errorMessage= "";

    public function __construct($model,$view){
        // Constructor to initialize the controller with a model and a view.
        $this->model=$model;
        $this->view=$view;
    }

    public function handleDashboardRequest(){
        // Handle requests to access the dashboard.
        if(!$this->model->isAuthenticated())
        {
            // Redirect to the login page if the user is not authenticated.
            header('Location: loginIndex.php');
        }
        else
        {
            // Render the dashboard if the user is authenticated.
            $this->view->renderDashboard($this->model, $this->successMessage, $this->errorMessage);
        }
    }
    
    public function handleRegisterRequest(){
        // Handle requests for user registration.
        if($this->model->isAuthenticated())
        {
            // Redirect to the home page if the user is already authenticated.
            header('Location: index.php');
        }
        if(isset($_POST["submit"]))
        {
            // Process the registration form submission.
            $fname = $_POST['fname'];
            $lname = $_POST['lname'];
            $email = $_POST['email'];
            $phone = $_POST['phone'];
            $password = $_POST['password'];

            // Attempt to register the user.
            $insert_result = $this->model->registerUser($fname, $lname, $email, $phone, $password);

            if($insert_result)
            {
                // Registration successful.
                $this->successMessage= 'You have been signed up successfully';
            }
            else
            {
                // Registration failed.
                $this->errorMessage= 'Something went wrong' . $this->model->getErrorMessage();
            }
        }
        // Render the registration form.
        $this->view->renderRegister($this->successMessage, $this->errorMessage);
    }

    public function handleLoginRequest(){
        // Handle requests for user login.
        if($this->model->isAuthenticated()){
            // Redirect to the home page if the user is already authenticated.
            header('Location: index.php');
        }

        if(isset($_POST['submit']))
        {
            // Process the login form submission.
            $email = $_POST['email'];
            $password = $_POST['password'];

            // Authenticate the user.
            $user = $this->model->authenticateUser($email, $password);
            if($user)
            {
                // Authentication successful. Store user information in the session.
                $_SESSION['user'] = $user;
                header('Location: index.php');
            }
            else
            {
                // Authentication failed.
                $this->errorMessage= 'Wrong login details';
                $this->view->renderLogin($this->successMessage, $this->errorMessage);
            }
            exit();
        }
        // Render the login form.
        $this->view->renderLogin($this->successMessage, $this->errorMessage);
    }

    public function handleLogoutRequest(){
        // Handle requests for user logout.
        session_destroy();
        // Redirect to the login page after destroying the session.
        header('Location: loginIndex.php');
    }
}
?>
