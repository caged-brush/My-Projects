<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$mydb = new mysqli("localhost", "root", "", "user_info");

if ($mydb->connect_errno) {
    echo "Failed to connect to database" . $mydb->connect_error;
}

if (isset($_POST['search'])) {
    $search_term = '%' . mysqli_real_escape_string($mydb, $_POST['search']) . '%';
    $queryFetch = $mydb->prepare("SELECT * FROM product_table WHERE product_name LIKE ?");
    $queryFetch->bind_param('s', $search_term);
    $queryFetch->execute();
    $result = $queryFetch->get_result();

} 

else
{
    // Default query to fetch all products if no search is performed
    $queryFetch = "SELECT * FROM product_table";
    $result = mysqli_query($mydb, $queryFetch);
}
?>

<html>
<head>
    <title>Result</title>
</head>
<body>
    <ul class="firstProduct">
    <?php
    
    
    // Check if there are results to display
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
    ?>
            <div>
                <li><img class="watch" src="uploads/<?php echo $row['image']; ?>" /></li>
                <span class="product-name"><?php echo $row['product_name']; ?></span>
                <br><br>
                <span class="price"><?php echo "$" . $row['price']; ?></span>
                <button class="cart">Add to Cart</button>
            </div>
    <?php
        }
    } else {
        // No results found or query issue
        echo "No results found";
    }
    ?>
</ul>

</body>
</html>
