Project Name: SJ Shops

Overview:
This web application was designed using HTML, CSS, JavaScript, and PHP. It includes an admin page dedicated to managing product data and an inventory for storing and updating product information.

Prerequisites:
To run this web application locally, ensure you have a localhost environment set up, such as XAMPP or WinSCP.

Setup Instructions:
Follow these steps to set up and run the web application:

Step 1: Start Localhost

Ensure your localhost environment (like XAMPP or WinSCP) is running.

Step 2: Database Setup

Locate the file named database_files.php.
Run this PHP file to create the necessary database and related tables in your database.
Step 3: Accessing Admin Features

Access the admin page by navigating to admin.php.
The admin page includes a form where product information can be entered and stored in the database.
Additionally, there is an inventory page within the admin section to manage stored product data.

New Page Information:
There's a specific page dedicated to viewing upcoming products that are not yet available for purchase. Users cannot add these upcoming products to their cart from this page.

This page serves as a preview for new items and does not support direct purchase functionality.

Login/Logout:
The login/logout functionality of this page has been designed using Model View Controller(MVC) this include session management for users

Notes:
Ensure proper configuration and security measures are taken, especially when handling databases and sensitive information.
Additional user permissions and security features may be implemented for the admin section as needed.

Troubleshooting:
If encountering issues with setup or functionality, refer to error messages, logs, or consult the documentation for the respective localhost environment being used.