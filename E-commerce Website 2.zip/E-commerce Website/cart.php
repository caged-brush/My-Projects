<?php
$mydb=new mysqli("localhost","root","","user_info");
if($mydb->connect_errno)
{
    echo "Failed to connect to MySql". $mydb ->connect_error;
    exit();
}

if (!$mydb->select_db("user_info")) {
    die("Failed to select database: " . $mydb->error);
}


?>

<!DOCTYPE html>
<html>
    <head>
        <title>Cart</title>
        <link href="cart.css" rel="Stylesheet">
        <link rel="icon" href="images/icon.png">
    </head>
    <body>
        <h1>Your cart</h1>
    <script src="code.jquery.com_jquery-3.7.1.js"></script>
    <script src="cart.js"></script>
    </body>
</html>