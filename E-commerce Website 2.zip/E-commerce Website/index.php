<?php
$mydb=new mysqli("localhost","root","","user_info");

if($mydb->connect_errno)
{
    echo "Failed to connect to database". $mydb->connect_error;
}
$queryFetch = "SELECT * FROM product_table";
$result = mysqli_query($mydb, $queryFetch);
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Welcome</title>
        <link href="main.css" rel="stylesheet">
        <link rel="icon" href="images/Suleiman Jibril.png">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <header>
            <h1 id="logo">SJ SHOPS</h1>
           
            <form action="search.php" method="post">
                    <div>
                        <label class="label" id="search-label" for="search">Search</label>
                        <input class="information" id="search-bar" type="text" name="search" placeholder="Search" required>
                    </div>

                    <div>
                        <Input type="submit" id="submit" name="search" value="Search">
                    </div>
                </form>

            <ul id="menu">

                <li class="menu"><a href="index.php">Home</a></li>
                <li class="menu"><a href="featured.html">New</a></li>
                <li class="menu"><a href="Login/index.php">Login</a></li>

                <div id="cart-container">
                    <li><img id="cart" src="images/cart.png"></li>
                    <p class="cart-number">0</p>
                </div>
                <div id="menu-container">
                    <li><img id="menu-logo" src="images/menu.png"></li>
                </div>
            </ul>
        </header>

        <div id="first">
            <h1 class="message">CHECK OUT OUR WATCH COLLECTION</h1>
            <button class="prev"><img class="prev-image" src="images/right-arrow.png"></button>
                <ul class="firstProduct">
                    
                    <?php
                    $res = mysqli_query($mydb, "SELECT * FROM product_table WHERE category = 'watches'");
                    while ($row = mysqli_fetch_assoc($res)) {
                    ?>
                        <div>
                            <li><img class="watch" src="uploads/<?php echo $row['image'] ?>"/></li>
                            <span class="product-name"><?php echo $row['product_name']; ?></span>
                            <br>
                            <br>
                            <span class="price"><?php echo "$" . $row['price']; ?></span>
                            <button class="cart">Add to Cart</button>
                        </div>
                        
                    <?php
                    }
                    ?>
                   
                </ul>
            <button class="next"><img class="next-image" src="images/right-arrow.png"></button>
        </div>


            <div id="second">
                
                <h1 class="message">CHECK OUT OUR HOODIE COLLECTION</h1>
                <button id="prev2"><img class="prev-image" src="images/right-arrow.png"></button>
                <ul class="secondProduct">

                <?php
                $hoodieQuery = "SELECT * FROM product_table WHERE category = 'hoodie'"; 
                $hoodieResult = mysqli_query($mydb, $hoodieQuery);

                
                while ($hoodieRow = mysqli_fetch_assoc($hoodieResult)) {
                ?>
                <div>
                    <li><img class="hoodie" src="uploads/<?php echo $hoodieRow['image']; ?>"></li>
                    <span class="product-name"><?php echo $hoodieRow['product_name']; ?></span>
                    <br><br>
                    <span class="price"><?php echo "$" . $hoodieRow['price']; ?></span>
                    <button class="cart">Add to Cart</button>
                </div>
                <?php
                }
                ?>
                </ul>
                <button id="next2"><img class="next-image" src="images/right-arrow.png"></button>
            </div>

            <div id="third">
                <h1 class="message">CHECK OUT OUR SHOE COLLECTION</h1>
                <button id="prev3"><img class="prev-image" src="images/right-arrow.png"></button>
                <ul class="thirdProduct">

                <?php
                $shoeQuery = "SELECT * FROM product_table WHERE category = 'shoe'"; 
                $shoeResult = mysqli_query($mydb, $shoeQuery);
                while ($shoeRow = mysqli_fetch_assoc($shoeResult)) 
                {
                    ?>
                    <div>
                        <li><img class="shoes" src="uploads/<?php echo $shoeRow['image']; ?>"></li>
                        <span class="product-name"><?php echo $shoeRow['product_name']; ?></span>
                        <br><br>
                        <span class="price"><?php echo "$" . $shoeRow['price']; ?></span>
                        <button class="cart">Add to Cart</button>
                    </div>
                    <?php
                }
                ?>
                </ul>
                <button id="next3"><img class="next-image" src="images/right-arrow.png"></button>
            </div>

            <div id="fourth">
                <h1 class="message" id="winter">CHECK OUT OUR  WINTER COLLECTION</h1>
                <button id="prev4"><img class="prev-image" src="images/right-arrow.png"></button>
                <ul class="fourthProduct">
                <?php
       
                $jacketQuery = "SELECT * FROM product_table WHERE category = 'winter'"; 
                $jacketResult = mysqli_query($mydb, $jacketQuery);

        
                while ($jacketRow = mysqli_fetch_assoc($jacketResult)) {
                ?>
                <div>
                    <li><img class="jacket" src="uploads/<?php echo $jacketRow['image']; ?>"></li>
                    <span class="product-name"><?php echo $jacketRow['product_name']; ?></span>
                    <br><br>
                    <span class="price"><?php echo "$" . $jacketRow['price']; ?></span>
                    <button class="cart">Add to Cart</button>
                </div>
                <?php
                }
                ?>
                </ul>

                <button id="next4"><img class="next-image" src="images/right-arrow.png"></button>
            </div>

            <div class="cartTab">
                <h1>Shopping Cart</h1>
                
                <div class="listCart">
                    <div class="item">
                       
                    </div>
                </div>
                <div class="total">
                    <h1>Total:</h1>
                    <span class="total-price">$0.00</span>
                </div>
                <div class="btn">
                    <button class="close">Close</button>
                    <button class="checkout">Check out</button>
                </div>
                <div class="clear">
               
             
                </div>
            </div>
        <script src="code.jquery.com_jquery-3.7.1.js"></script>
        <script src="main.js"></script>
    </body>
</html>